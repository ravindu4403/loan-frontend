import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import DashboardLayout from "../layouts/DashboardLayout";
import Swal from "sweetalert2";
import "animate.css";
import Select from "react-select";


export default function Payments() {
  const [loans, setLoans] = useState([]);
  const [payments, setPayments] = useState([]);
  const [formData, setFormData] = useState({
    id: null,
    loan_id: "",
    payee: "",
    amount: "",
    penalty_amount: 0,
  });
  const [editing, setEditing] = useState(false);
  const [selectedLoan, setSelectedLoan] = useState("");
  const [loanSummary, setLoanSummary] = useState({
    totalLoan: 0,
    totalPaid: 0,
    balance: 0,
    interestRate: 0,
    interestRs: 0,
    monthlyPayment: 0,
    totalPayable: 0,
    nextPaymentDate: "",
  });

  useEffect(() => {
    fetchLoans();
    fetchPayments();
  }, []);

  // 🔹 Fetch only Released loans (status = 3)
  async function fetchLoans() {
  const { data, error } = await supabase
    .from("loan_list")
    .select(`
  id,
  ref_no,
  amount,
  status,
  next_payment_date,
  date_released,
  borrowers(firstname, lastname)
`)

    .eq("status", 3);

  if (!error) setLoans(data || []);
}


  async function fetchPayments() {
    const { data, error } = await supabase
  .from("payments")
  .select(
    "id, loan_id, payee, amount, penalty_amount, next_payment_date, date_created, loan_list(ref_no, borrowers(id_no))"
  );



    if (!error) setPayments(data || []);
  }

 async function handleLoanChange(e) {
  const loanId = e.target.value;
  setSelectedLoan(loanId);

  if (!loanId) return;

  // 🔹 Supabase එකෙන් loan එක ගන්නවා
  const { data: loanData, error } = await supabase
    .from("loan_list")
    .select(`
      id, ref_no, amount, rate, term, next_payment_date, date_released, first_payment_date, paid_days,
      borrowers(firstname, lastname, id_no)
    `)
    .eq("id", loanId)
    .single();

  if (error || !loanData) {
    console.error("Loan not found:", error?.message);
    setLoanSummary({});
    return;
  }

  // 🧮 Daily calculation
  const amount = Number(loanData.amount);
  const months = Number(loanData.term);
  const rate = Number(loanData.rate);
  const totalInterest = amount * (rate / 100) * months;
  const totalPayable = amount + totalInterest;
  const totalDays = months * 30;
  const dailyPayment = totalPayable / totalDays;

  // 🧮 Already paid days count (get before using)
  const { count: paidDaysCount } = await supabase
    .from("payments")
    .select("*", { count: "exact", head: true })
    .eq("loan_id", loanId);

 // 🗓️ Next payment date (if not available)
// 🗓️ Next payment date calculation
let nextPaymentDate;

if (loanData.first_payment_date) {
  // If first_payment_date exists → next = first + 1
  const firstPay = new Date(loanData.first_payment_date);
  firstPay.setDate(firstPay.getDate() + 1);
  nextPaymentDate = firstPay.toISOString().split("T")[0];
} else {
  // If not → next = release + 2
  const release = new Date(loanData.date_released);
  release.setDate(release.getDate() + 2);
  nextPaymentDate = release.toISOString().split("T")[0];
}


  // 🗓️ Release date
  const releaseDate = loanData.date_released
    ? new Date(loanData.date_released)
    : new Date();

  // 🧮 Remaining days = totalDays - paidDaysCount
  const remainingDays = Math.max(0, totalDays - (paidDaysCount || 0));

// 💾 Update loan summary UI
setLoanSummary({
  loanId: loanData.id,
  payeeName: `${loanData.borrowers?.firstname || ""} ${loanData.borrowers?.lastname || ""}`,
  borrowerIdNo: loanData.borrowers?.id_no || "",
  loanAmount: amount.toFixed(2),
  interestRate: rate,
  totalPayable: totalPayable.toFixed(2),
  dailyPayment: dailyPayment.toFixed(2),
  nextPaymentDate: loanData.next_payment_date || nextPaymentDate,  // ✅ FIX HERE
  releaseDate: releaseDate.toLocaleDateString("en-CA"),
  paidDays: paidDaysCount || 0,
  firstPaymentDate: loanData.first_payment_date
    ? new Date(loanData.first_payment_date).toLocaleDateString("en-CA")
    : "N/A",
  remainingDays,
});


  // 💾 Update form data
  setFormData({
    ...formData,
    loan_id: loanData.id,
    payee: `${loanData.borrowers?.firstname || ""} ${loanData.borrowers?.lastname || ""}`,
    amount: dailyPayment.toFixed(2),
    penalty_amount: 0,
  });
}



async function handleSubmit(e) {
  e.preventDefault();

  // 🛑 Validate loan selection
  if (!formData.loan_id) {
    Swal.fire({
      title: "No Loan Selected!",
      text: "Please select a loan before adding a payment.",
      icon: "warning",
      confirmButtonColor: "#facc15",
      background: "#1a2238",
      color: "#fff",
    });
    return;
  }

  if (editing) {
    const { error } = await supabase
      .from("payments")
      .update({
        loan_id: formData.loan_id,
        payee: formData.payee,
        amount: formData.amount,
        penalty_amount: formData.penalty_amount,
      })
      .eq("id", formData.id);

    if (!error) {
      Swal.fire({
        title: "Payment Updated!",
        text: "Payment details have been updated successfully.",
        icon: "success",
        confirmButtonColor: "#22c55e",
        background: "#1a2238",
        color: "#fff",
      });
      setEditing(false);
      fetchPayments();
      setFormData({ id: null, loan_id: "", payee: "", amount: "", penalty_amount: 0 });
    }
    return;
  }

  // 🧩 Get loan info before insert
  const { data: loanData, error: loanError } = await supabase
  .from("loan_list")
  .select("id, first_payment_date, paid_days, term, date_released")
  .eq("id", formData.loan_id)
  .single();

if (loanError || !loanData) {
  console.error("Loan data not found:", loanError?.message);
  Swal.fire({
    title: "Loan Not Found!",
    text: "Please select a valid loan before proceeding.",
    icon: "error",
    confirmButtonColor: "#ef4444",
    background: "#1a2238",
    color: "#fff",
  });
  return;
}


  // 🧮 If first_payment_date is null → set it to releaseDate + 1
  let firstPaymentDate = loanData.first_payment_date;
  if (!firstPaymentDate) {
    const release = new Date(loanData.date_released);
    release.setDate(release.getDate() + 1);
    firstPaymentDate = release.toISOString().split("T")[0];

    await supabase
      .from("loan_list")
      .update({ first_payment_date: firstPaymentDate })
      .eq("id", loanData.id);
  }

  // 🧮 Calculate next payment date
 const paidDays = (loanData.paid_days || 0) + 1;
const firstPayment = new Date(firstPaymentDate);
const nextPayment = new Date(firstPayment);
nextPayment.setDate(firstPayment.getDate() + paidDays);


  // ✅ Insert payment with next_payment_date
  // ✅ Insert payment & immediately fetch the new record
const { data: insertedPayment, error } = await supabase
  .from("payments")
  .insert([
    {
      loan_id: formData.loan_id,
      payee: formData.payee,
      amount: formData.amount,
      penalty_amount: formData.penalty_amount || 0,
      next_payment_date: nextPayment.toISOString().split("T")[0],
    },
  ])
  .select("*, loan_list(next_payment_date)") // ✅ Get related loan info
  .single();


  if (!error) {
    // 💾 Update loan record
    await supabase
      .from("loan_list")
      .update({
        paid_days: paidDays,
        next_payment_date: nextPayment.toISOString().split("T")[0],
      })
      .eq("id", loanData.id);

    // 🧮 Optional: Close loan if done
    const totalDays = (loanData.term || 0) * 30;
    if (paidDays >= totalDays) {
      await supabase
        .from("loan_list")
        .update({ status: 4 })
        .eq("id", loanData.id);
    }

// 🔄 Refresh lists
await fetchPayments();
await fetchLoans();

// 🔁 Update UI instantly using returned payment
if (insertedPayment?.loan_list?.next_payment_date) {
  setLoanSummary((prev) => ({
    ...prev,
    nextPaymentDate: insertedPayment.loan_list.next_payment_date,
    paidDays: (prev.paidDays || 0) + 1,
    remainingDays: Math.max(0, (loanData.term * 30) - ((loanData.paid_days || 0) + 1)),
  }));
}


// ✅ Show success message
Swal.fire({
  title: "Payment Added!",
  text: "Your payment has been recorded successfully.",
  icon: "success",
  confirmButtonColor: "#facc15",
  background: "#1a2238",
  color: "#fff",
});



    setFormData({
      id: null,
      loan_id: "",
      payee: "",
      amount: "",
      penalty_amount: 0,
    });
  }






 
 
}

 async function handleDelete(id) {
  const result = await Swal.fire({
    title: "Are you sure?",
    text: "This payment will be permanently deleted!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#ef4444",
    cancelButtonColor: "#6b7280",
    confirmButtonText: "Yes, delete it!",
    background: "#1a2238",
    color: "#fff",
  });

  if (!result.isConfirmed) return;

  // 🔹 Find the deleted payment’s loan_id first
  const payment = payments.find((p) => p.id === id);
  if (!payment) return;

  const loanId = payment.loan_id;

  // 🔹 Delete the payment
  const { error } = await supabase.from("payments").delete().eq("id", id);

  if (error) {
    console.error("Delete failed:", error.message);
    return;
  }

  // 🧮 Get remaining payment count
  const { count: newPaidDays } = await supabase
    .from("payments")
    .select("*", { count: "exact", head: true })
    .eq("loan_id", loanId);

  // 🧩 Get loan info again
  const { data: loanData } = await supabase
    .from("loan_list")
    .select("term, first_payment_date")
    .eq("id", loanId)
    .single();

  const totalDays = (loanData.term || 0) * 30;
 const firstPaymentDate = new Date(loanData.first_payment_date);
const newNextPayment = new Date(firstPaymentDate);
newNextPayment.setDate(firstPaymentDate.getDate() + newPaidDays + 1);

// 💾 Update Supabase loan_list
await supabase
  .from("loan_list")
  .update({
    paid_days: newPaidDays,
    next_payment_date: newNextPayment.toISOString().split("T")[0],
  })
  .eq("id", loanId);


  // 🧮 Remaining Days calculation
  const remainingDays = Math.max(0, totalDays - newPaidDays);

  // 🧠 Update UI instantly
  setLoanSummary((prev) => ({
    ...prev,
    paidDays: newPaidDays,
    nextPaymentDate: newNextPayment.toISOString().split("T")[0],
    remainingDays,
  }));

  // 🔄 Refresh tables
  await fetchPayments();
  await fetchLoans();

  Swal.fire({
    title: "Deleted!",
    text: "Payment has been removed.",
    icon: "success",
    confirmButtonColor: "#22c55e",
    background: "#1a2238",
    color: "#fff",
  });
}




  function handleEdit(payment) {
    setFormData({
      id: payment.id,
      loan_id: payment.loan_id,
      payee: payment.payee,
      amount: payment.amount,
      penalty_amount: payment.penalty_amount,
    });
    setEditing(true);
  }

  return (
    <DashboardLayout>
      <div className="p-6 text-white">
        <h2 className="text-2xl font-semibold mb-4">💵 Payments Management</h2>

        {/* Payment Form */}
        <form onSubmit={handleSubmit} className="flex flex-wrap gap-3 mb-6 items-center justify-between w-full max-w-full overflow-x-auto">
       <Select
  isSearchable={true}
  menuPlacement="auto"
  menuShouldScrollIntoView={false}
  menuPortalTarget={document.body}   // 🔹 ADD THIS LINE
  options={loans.map((loan) => ({
    value: loan.id,
    label: `${loan.ref_no} — ${loan.borrowers?.firstname || ""} ${loan.borrowers?.lastname || ""} (Rs.${loan.amount})`,
  }))}

value={
  selectedLoan
    ? {
        value: selectedLoan,
        label:
          loans.find((l) => l.id === selectedLoan)?.ref_no || "Select Loan",
      }
    : null
}

 onChange={(selected) => handleLoanChange({ target: { value: selected ? selected.value : "" } })}
  placeholder="🔍 Type Loan Ref or Borrower Name..."
  className="text-black flex-1 min-w-[250px] z-50"   // 🔹 ADD z-50
  styles={{
    control: (base) => ({
      ...base,
      backgroundColor: "#202a40",
      color: "white",
      border: "none",
    }),
    singleValue: (base) => ({ ...base, color: "white" }),
    input: (base) => ({ ...base, color: "white" }),
    menuPortal: (base) => ({ ...base, zIndex: 9999 }),   // 🔹 ADD THIS TOO
    menu: (base) => ({ ...base, backgroundColor: "#1a2238", color: "white" }),
    option: (base, state) => ({
      ...base,
      backgroundColor: state.isFocused ? "#2a3552" : "#1a2238",
      color: "white",
    }),
  }}
/>



          <input
            type="text"
            placeholder="Payee Name"
            className="bg-[#202a40] text-white px-4 py-2 rounded-md flex-1 min-w-[180px]"
            value={formData.payee}
            onChange={(e) => setFormData({ ...formData, payee: e.target.value })}
          />

          <input
            type="number"
            placeholder="Payment Amount"
            className="bg-[#202a40] text-white px-4 py-2 rounded-md w-full sm:w-40"
            value={formData.amount}
            onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
          />

          <input
            type="number"
            placeholder="Penalty"
            className="bg-[#202a40] text-white px-4 py-2 rounded-md w-full sm:w-40"
            value={formData.penalty_amount}
            onChange={(e) =>
              setFormData({ ...formData, penalty_amount: e.target.value })
            }
          />

          <button
            type="submit"
            className={`${
              editing
                ? "bg-green-500 hover:bg-green-600"
                : "bg-yellow-500 hover:bg-yellow-600"
            } text-black font-semibold px-6 py-2 rounded-md`}
          >
            {editing ? "Update Payment" : "Add Payment"}
          </button>
        </form>

        {/* Loan Summary */}
        {formData.loan_id && (
          <div className="bg-[#1a2238] p-5 mb-6 rounded-lg grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
           <div>💰 Loan Amount: Rs. {loanSummary.loanAmount || "N/A"}</div>
    <div>📈 Interest Rate: {loanSummary.interestRate || 0}%</div>
    <div>💵 Daily Payment: Rs. {loanSummary.dailyPayment || "N/A"}</div>
    <div>💸 Total Payable: Rs. {loanSummary.totalPayable || "N/A"}</div>
    <div>📅 First Payment Date: {loanSummary.firstPaymentDate || "N/A"}</div>
    <div>📅 Next Payment Date: {loanSummary.nextPaymentDate || "N/A"}</div>
    <div>🗓️ Release Date: {loanSummary.releaseDate || "N/A"}</div>
<div>📅 Paid Days: {loanSummary.paidDays || 0}</div>
<div>⏳ Remaining Days: {loanSummary.remainingDays || 0}</div>


          </div>
        )}

        {/* Payments Table */}
        <table className="w-full bg-[#1a2238] text-white rounded-lg overflow-hidden">
          <thead className="bg-[#2b364f] text-yellow-400">
            <tr>
              <th className="p-3 text-left">Loan Ref</th>
              <th className="p-3 text-left">Payee</th>
              <th className="p-3 text-left">Borrower ID No</th>
              <th className="p-3 text-left">Amount</th>
              <th className="p-3 text-left">Penalty</th>
              <th className="p-3 text-left">Total</th>
              <th className="p-3 text-left">Date</th>
              <th className="p-3 text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {payments.map((p) => (
              <tr key={p.id} className="border-b border-gray-700 hover:bg-[#2a3552]">
                <td className="p-3">{p.loan_list?.ref_no}</td>
                <td className="p-3">{p.payee}</td>
                <td className="p-3">{p.loan_list?.borrowers?.id_no || "N/A"}</td>
                <td className="p-3">Rs.{p.amount}</td>
                <td className="p-3">Rs.{p.penalty_amount}</td>
                <td className="p-3">
                  Rs.{parseFloat(p.amount) + parseFloat(p.penalty_amount)}
                </td>
                <td className="p-3">
                  {new Date(p.date_created).toLocaleDateString()}
                </td>
                <td className="p-3 flex justify-center gap-2">
                  <button
                    onClick={() => handleEdit(p)}
                    className="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded-md text-sm"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(p.id)}
                    className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-md text-sm"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
            {payments.length === 0 && (
              <tr>
                <td colSpan="7" className="text-center p-4 text-gray-400">
                  No payments found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </DashboardLayout>
  );
}
