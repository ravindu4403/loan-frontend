import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import DashboardLayout from "../layouts/DashboardLayout";
import jsPDF from "jspdf";
import "jspdf-autotable";
import Swal from "sweetalert2";

export default function Reports() {
  const [loans, setLoans] = useState([]);
  const [filteredLoans, setFilteredLoans] = useState([]);
  const [dateRange, setDateRange] = useState({ start: "", end: "" });
  const [summary, setSummary] = useState({
    totalLoanValue: 0,
    totalPaid: 0,
    interestEarned: 0,
    pendingBalance: 0,
  });

  useEffect(() => {
    fetchLoansAndPayments();
  }, []);

  async function fetchLoansAndPayments() {
    const { data, error } = await supabase
      .from("loan_list")
      .select(`
        id, ref_no, amount, status, date_released,
        borrowers(firstname, lastname),
        loan_plan(months, interest_percentage),
        payments(amount, penalty_amount, date_created)
      `)
      .eq("status", 3); // Released only

    if (error) {
      console.error("Loan fetch error:", error);
      return;
    }

    // Released loans — even without payments
    setLoans(data || []);
    setFilteredLoans(data || []);
    calculateSummary(data);
  }

  function calculateSummary(data) {
    if (!data || data.length === 0) {
      setSummary({
        totalLoanValue: 0,
        totalPaid: 0,
        interestEarned: 0,
        pendingBalance: 0,
      });
      return;
    }

    let totalLoanValue = 0;
    let totalPaid = 0;
    let interestEarned = 0;
    let pendingBalance = 0;

    data.forEach((loan) => {
      const amount = parseFloat(loan.amount) || 0;
      const rate = parseFloat(loan.loan_plan?.interest_percentage) || 0;
      const months = parseInt(loan.loan_plan?.months) || 1;
      const monthlyInterest = (amount * rate) / 100;
      const totalPayable = amount + monthlyInterest * months;

      const totalPayments =
        loan.payments?.reduce(
          (sum, p) =>
            sum + parseFloat(p.amount || 0) + parseFloat(p.penalty_amount || 0),
          0
        ) || 0;

      const monthsPaid = Math.floor(
        totalPayments / (amount / months + monthlyInterest)
      );
      const earnedInterest = monthsPaid * monthlyInterest;

      totalLoanValue += totalPayable;
      totalPaid += totalPayments;
      interestEarned += earnedInterest;
      pendingBalance += totalPayable - totalPayments;
    });

    setSummary({
      totalLoanValue: totalLoanValue.toFixed(2),
      totalPaid: totalPaid.toFixed(2),
      interestEarned: interestEarned.toFixed(2),
      pendingBalance: pendingBalance.toFixed(2),
    });
  }

  function filterByDate() {
    if (!dateRange.start || !dateRange.end) {
      Swal.fire("⚠️", "Please select both start and end dates!", "warning");
      return;
    }

    const filtered = loans.filter((loan) => {
      const d = new Date(loan.date_released);
      return d >= new Date(dateRange.start) && d <= new Date(dateRange.end);
    });

    setFilteredLoans(filtered);
    calculateSummary(filtered);

    Swal.fire({
      icon: "success",
      title: "✅ Filter Applied!",
      text: `Showing data from ${dateRange.start} to ${dateRange.end}`,
      timer: 1800,
      showConfirmButton: false,
    });
  }

  function exportPDF() {
    if (!filteredLoans || filteredLoans.length === 0) {
      Swal.fire("⚠️", "No released loans to export!", "warning");
      return;
    }

    const doc = new jsPDF("landscape");
    doc.setFontSize(16);
    doc.text("VIDUNI INVESTMENT (P.V.T) LTD", 14, 15);
    doc.setFontSize(12);
    doc.text("Released Loans Report", 14, 25);
    doc.text(
      `Date Range: ${dateRange.start || "All"} - ${dateRange.end || "All"}`,
      14,
      33
    );

    doc.autoTable({
      startY: 40,
      head: [
        [
          "Ref No",
          "Borrower",
          "Amount",
          "Interest (%)",
          "Months",
          "Loan Date",
          "Total Paid",
          "Pending",
        ],
      ],
      body: filteredLoans.map((l) => {
        const borrowerName = `${l.borrowers?.firstname || ""} ${
          l.borrowers?.lastname || ""
        }`;
        const amount = parseFloat(l.amount) || 0;
        const rate = parseFloat(l.loan_plan?.interest_percentage) || 0;
        const months = parseInt(l.loan_plan?.months) || 1;
        const monthlyInterest = (amount * rate) / 100;
        const totalPayable = amount + monthlyInterest * months;
        const totalPaid =
          l.payments?.reduce(
            (sum, p) =>
              sum + parseFloat(p.amount || 0) + parseFloat(p.penalty_amount || 0),
            0
          ) || 0;
        const pending = totalPayable - totalPaid;
        const loanDate = new Date(l.date_released).toLocaleDateString();

        return [
          l.ref_no,
          borrowerName || "N/A",
          `Rs.${amount.toFixed(2)}`,
          `${rate}%`,
          months,
          loanDate,
          `Rs.${totalPaid.toFixed(2)}`,
          `Rs.${pending.toFixed(2)}`,
        ];
      }),
    });

    const finalY = doc.lastAutoTable.finalY + 10;
    doc.text(`Summary`, 14, finalY);
    doc.text(`Total Loan Value (With Interest): Rs.${summary.totalLoanValue}`, 14, finalY + 8);
    doc.text(`Total Paid: Rs.${summary.totalPaid}`, 14, finalY + 16);
    doc.text(`Interest Earned (So Far): Rs.${summary.interestEarned}`, 14, finalY + 24);
    doc.text(`Pending Balance: Rs.${summary.pendingBalance}`, 14, finalY + 32);

    doc.save("released_loan_report.pdf");

    Swal.fire({
      icon: "success",
      title: "📄 PDF Exported Successfully!",
      timer: 2000,
      showConfirmButton: false,
    });
  }

  return (
    <DashboardLayout>
      <div className="p-6 text-white">
        <h2 className="text-2xl font-semibold mb-6">📊 Released Loans Report</h2>

        {/* Filter Controls */}
        <div className="flex flex-wrap gap-3 mb-6">
          <input
            type="date"
            className="bg-[#202a40] px-4 py-2 rounded-md text-white"
            value={dateRange.start}
            onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
          />
          <input
            type="date"
            className="bg-[#202a40] px-4 py-2 rounded-md text-white"
            value={dateRange.end}
            onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
          />
          <button
            onClick={filterByDate}
            className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold px-6 py-2 rounded-md transition-all"
          >
            Filter
          </button>
          <button
            onClick={exportPDF}
            className="bg-green-500 hover:bg-green-600 text-black font-semibold px-6 py-2 rounded-md transition-all"
          >
            Export PDF
          </button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <SummaryCard title="💰 Total Loan Value (With Interest)" value={`Rs.${summary.totalLoanValue}`} />
          <SummaryCard title="💵 Total Paid" value={`Rs.${summary.totalPaid}`} />
          <SummaryCard title="📈 Interest Earned (So Far)" value={`Rs.${summary.interestEarned}`} />
          <SummaryCard title="🧾 Pending Balance" value={`Rs.${summary.pendingBalance}`} />
        </div>

        {/* Data Table */}
        <table className="w-full bg-[#1a2238] text-white rounded-lg overflow-hidden">
          <thead className="bg-[#2b364f] text-yellow-400">
            <tr>
              <th className="p-3 text-left">Ref No</th>
              <th className="p-3 text-left">Borrower</th>
              <th className="p-3 text-left">Amount</th>
              <th className="p-3 text-left">Interest (%)</th>
              <th className="p-3 text-left">Months</th>
              <th className="p-3 text-left">Loan Date</th>
              <th className="p-3 text-left">Total Paid</th>
              <th className="p-3 text-left">Pending</th>
            </tr>
          </thead>
          <tbody>
            {filteredLoans.map((l) => {
              const borrowerName = `${l.borrowers?.firstname || ""} ${l.borrowers?.lastname || ""}`;
              const amount = parseFloat(l.amount) || 0;
              const rate = parseFloat(l.loan_plan?.interest_percentage) || 0;
              const months = parseInt(l.loan_plan?.months) || 1;
              const monthlyInterest = (amount * rate) / 100;
              const totalPayable = amount + monthlyInterest * months;
              const totalPaid =
                l.payments?.reduce(
                  (sum, p) => sum + parseFloat(p.amount || 0) + parseFloat(p.penalty_amount || 0),
                  0
                ) || 0;
              const pending = totalPayable - totalPaid;
              const loanDate = new Date(l.date_released).toLocaleDateString();

              return (
                <tr key={l.id} className="border-b border-gray-700 hover:bg-[#2a3552]">
                  <td className="p-3">{l.ref_no}</td>
                  <td className="p-3">{borrowerName}</td>
                  <td className="p-3">Rs.{amount.toFixed(2)}</td>
                  <td className="p-3">{rate}%</td>
                  <td className="p-3">{months}</td>
                  <td className="p-3">{loanDate}</td>
                  <td className="p-3">Rs.{totalPaid.toFixed(2)}</td>
                  <td className="p-3 text-yellow-400">Rs.{pending.toFixed(2)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </DashboardLayout>
  );
}

function SummaryCard({ title, value }) {
  return (
    <div className="bg-[#1a2238] p-5 rounded-lg shadow-md hover:shadow-lg transition-all duration-300">
      <h4 className="text-yellow-400 font-semibold mb-2">{title}</h4>
      <p className="text-xl font-bold">{value}</p>
    </div>
  );
}
